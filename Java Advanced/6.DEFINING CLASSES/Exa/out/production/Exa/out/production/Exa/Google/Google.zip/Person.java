package Google;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Person {
    private Company company;
    private Car car;
    private Pokemons pokemons;
    private Children children;
    private Parents parents;

    public void addInfo(String[] tokens){
        switch (tokens[1]) {
            case "company":
            this.company=new Company(tokens[2]+" "+tokens[3],Double.parseDouble(tokens[4]));
                break;
            case "car":
                if (this.car==null){
                   this.car=new Car(tokens[2]+" "+tokens[3]);
                }
                break;
            case "pokemon":
                if (this.pokemons==null){
                    this.pokemons=new Pokemons();
                }
                this.pokemons.getPokemons().add(tokens[2]+" "+tokens[3]);
                break;
            case "parents":
                if (this.parents==null){
                   this.parents=new Parents();
                }
                  this.parents.getParents().add(tokens[2]+" "+tokens[3]);
                break;
            case "children":
                if (this.children==null){
                    this.children=new Children();
                }
                this.children.getChildren().add(tokens[2]+" "+tokens[3]);
                break;
        }
    }
    public void setCompany(Company company) {
        this.company = company;
    }

    public String toSting() {
        StringBuilder print = new StringBuilder();

        print.append("Company:");
        print.append(System.lineSeparator());
        if (company != null) {
            print.append(company.toString());
            print.append(System.lineSeparator());
        }


        print.append("Car:");
        print.append(System.lineSeparator());
        if (car != null) {
            print.append(car.getCar());
            print.append(System.lineSeparator());
        }
        print.append("Pokemon:");
        print.append(System.lineSeparator());
        if (pokemons!=null) {

            for (String p: pokemons.getPokemons()
                 ) {
                print.append(p);
                print.append(System.lineSeparator());
            }
        }
        print.append("Parents:");
        print.append(System.lineSeparator());
        if (parents!= null) {
            for (String p: parents.getParents()
            ) {
                print.append(p);
                print.append(System.lineSeparator());
            }
        }

        print.append("Children:");
        print.append(System.lineSeparator());
        if (children!=null) {
            for (String p: children.getChildren()
            ) {
                print.append(p);
                print.append(System.lineSeparator());
            }
        }
        return print.toString();
    }

}
