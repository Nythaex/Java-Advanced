package Google;

public class Car {
   private String car;

    public Car(String car) {
        this.car = car;
    }

    public String getCar() {
        return car;
    }
}
