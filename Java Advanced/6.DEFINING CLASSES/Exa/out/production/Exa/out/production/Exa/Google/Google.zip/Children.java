package Google;

import java.util.ArrayList;
import java.util.List;

public class Children {
    private List<String> children=new ArrayList<>();

    public Children() {
        this.children = new ArrayList<>();
    }

    public List<String> getChildren() {
        return this.children;
    }


}
