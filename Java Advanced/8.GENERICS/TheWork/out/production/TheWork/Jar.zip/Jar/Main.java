package Jar;

import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        Jar<Integer> colection=new Jar<Integer>();
        colection.add(213);
        colection.add(122);
        colection.remove();
    }
}
