package guild;

import java.util.ArrayList;
import java.util.List;

public class Guild {

    private String name;
    private int capacity;
    private List<Player> roster;

    public Guild(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.roster = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        if (roster.size() < capacity) {
            this.roster.add(player);
        }
    }

    public boolean removePlayer(String name) {
        return this.roster.removeIf(s -> s.getName().equals(name));
    }

    public void promotePlayer(String name) {
        for (Player player : roster
        ) {
            if (player.getName().equals(name)) {
                player.setRank("Member");
                break;
            }
        }
    }

    public void demotePlayer(String name) {
        for (Player player : roster
        ) {
            if (player.getName().equals(name)) {
                player.setRank("Trial");
                break;
            }
        }
    }

    public Player[] kickPlayersByClass(String clazz) {
        return this.roster.stream().filter(player -> player.getClazz().equals(clazz)).toArray(Player[]::new);
    }

    public int count() {
        return this.roster.size();
    }

    public String report() {
        StringBuilder output = new StringBuilder("Players in the guild: ");
        output.append(getName()).append(":").append(System.lineSeparator());
        getRoster().forEach(e -> output.append(e).append(System.lineSeparator()));
        return output.toString();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Player> getRoster() {
        return roster;
    }

    }
}
