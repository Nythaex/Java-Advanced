package healthyHeaven;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private String name;
    private List<Salad> data;

    public Restaurant(String name) {
        this.name = name;
        this.data=new ArrayList<>();
    }
    public void add(Salad s) {
        data.add(s);
    }
    public boolean buy(String saladName) {
        return data.remove(saladName);
    }
    public Salad getHealthiestSalad() {
        int healthiestName=-1;
        int healthiest=Integer.MAX_VALUE;
        int i=0;
        for (Salad s:data
        ) {
            if (s.getTotalCalories()<healthiest){
                healthiest=s.getTotalCalories();
                healthiestName=i;
            }
            i++;
        }
        return data.get(healthiestName);
    }

    public String generateMenu() {
        StringBuilder printer=new StringBuilder();
        printer.append(String.format("%s have %d salads:",this.name,this.data.size()));
        for (Salad s:this.data
        ) {
            printer.append(System.lineSeparator());
            printer.append(s.toString());
        }
        return printer.toString();
    }
}
