package PointInRectangle;

public class Rectangle {
    private int botFirst;
    private int botSecond;
    private int topFirst;
    private int topSecond;

    public Rectangle(int botFirst, int botSecond, int topFirst, int topSecond) {
        this.botFirst = botFirst;
        this.botSecond = botSecond;
        this.topFirst = topFirst;
        this.topSecond = topSecond;
    }
    public boolean contains(Point point){
        return contain(point);
    }

    private boolean contain(Point point) {
        return point.getFirstPoint()>=botFirst&&point.getFirstPoint()>=botSecond&&
         point.getFirstPoint()<=topFirst&&point.getFirstPoint()<=topSecond&&
                point.getSecondPoint()>=botFirst&&point.getSecondPoint()>=botSecond&&
                point.getSecondPoint()<=topFirst&&point.getSecondPoint()<=topSecond;


    }
}
