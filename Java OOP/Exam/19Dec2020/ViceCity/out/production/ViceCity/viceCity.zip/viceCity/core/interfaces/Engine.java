package viceCity.core.interfaces;

public interface Engine extends Runnable {
}
