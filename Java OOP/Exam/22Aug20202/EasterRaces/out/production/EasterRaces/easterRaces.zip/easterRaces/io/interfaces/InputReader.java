package easterRaces.io.interfaces;

import java.io.IOException;

public interface InputReader {
    String readLine() throws IOException;
}
