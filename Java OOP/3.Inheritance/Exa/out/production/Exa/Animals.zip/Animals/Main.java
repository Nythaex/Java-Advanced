package Animals;

public class Main {
    public static void main(String[] args) {
        Tomcat cat=new Tomcat("Tom",12,"afs");
        System.out.println(cat.toString());
    }
}
