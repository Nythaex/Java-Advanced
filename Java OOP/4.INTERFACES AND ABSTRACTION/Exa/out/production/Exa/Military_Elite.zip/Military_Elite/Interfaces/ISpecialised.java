package Military_Elite.Interfaces;

import Military_Elite.enums.Corp;

public interface ISpecialised {
    Corp getCorp();
    String toString();
}
