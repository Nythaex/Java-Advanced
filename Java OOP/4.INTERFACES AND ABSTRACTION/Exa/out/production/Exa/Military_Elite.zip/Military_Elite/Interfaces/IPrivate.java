package Military_Elite.Interfaces;

public interface IPrivate {
    double getSalary();
    String toString();
}
