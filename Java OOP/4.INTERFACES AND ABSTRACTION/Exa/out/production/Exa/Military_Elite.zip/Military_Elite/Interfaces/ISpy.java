package Military_Elite.Interfaces;

public interface ISpy {
    String getCode();
    String toString();
}
