package Military_Elite.Interfaces;

public interface ISoldier {
    int getID();
    String getFirstName();
    String getLastName();
    String toString();
}
